package event;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import event.control.UserManager;
import event.util.BaseException;

public class UserManagerTest {

	@Before
	public void setUp() throws Exception {
	}
	UserManager um = new UserManager();
	@Test
	public void testCreateUser()   {
		//fail("Not yet implemented");
		try {
			um.createUser("001", "001", "002");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 assertTrue(e.getMessage().contains("�����������벻һ��")); 
		}
		try {
			um.createUser("G06", "001", "001");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 assertTrue(e.getMessage().contains("���û��Ѵ���"));
		}
		try {
			um.createUser("", "1", "1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 assertTrue(e.getMessage().contains("�û��������벻��Ϊ��"));
		}
	}

	@Test
	public void testLogin()  {
		//fail("Not yet implemented");
		try {
			um.login("G06", "000");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(e.getMessage().contains("�����������"));
		}
		
	}

	@Test
	public void testModifyPwd() {
		//fail("Not yet implemented");
		try {
			um.modifyPwd("G06", "000", "002","002");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(e.getMessage().contains("�����������"));
			
		}
		
		try {
			um.modifyPwd("G06", "001", "002","003");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(e.getMessage().contains("�����������벻һ��"));
		}
		try {
			um.modifyPwd("G06", "001", "","");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 assertTrue(e.getMessage().contains("�����벻��Ϊ��"));
		}
	}


	@Test
	public void testLoaduser()  {
		//fail("Not yet implemented");
		try {
			um.loaduser("100");
		} catch (BaseException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(e.getMessage().contains("��½�˺Ų�����"));
			
		}
		try {
			um.loaduser("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 assertTrue(e.getMessage().contains("�û�������Ϊ��"));
		}
	}

}
