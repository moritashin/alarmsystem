package event.control;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import event.util.DBUtil;
import event.model.*;
public class EventManager {
	public int getaddEventNum(String contect,String reminderTime,String state,String reminderMode,String classification )throws Exception{
    	Time t = new Time();
		if(t.timeCompare(t.getCurrentTime(), reminderTime)>=0){
			throw new Exception("ʱ�����ò���������ʱ���ѹ�");
		}
		if(contect.length()>200 ){
			throw new Exception("�������ݳ��Ȳ��ܳ���200����");
			
		}
		Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(reminderTime);
		Date afterDate = new Date(date .getTime() - 300000);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");  
	    String dateString = formatter.format(afterDate);  
		if(t.timeCompare(t.getCurrentTime(), dateString)>=0){
			throw new Exception("ʱ���С��5����");
		}
		int num=0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select count(*) from beanevent where reminderTime = ? ";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setTimestamp(1,new java.sql.Timestamp(date.getTime()));
			java.sql.ResultSet rs = pst.executeQuery();
			if(rs.next()){
				num = rs.getInt(1);
			}	
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
		return num;
    }
	public void addEvent(String contect,String reminderTime,String state,String reminderMode,String classification )throws Exception{
		Date date =  new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(reminderTime);
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="insert into Beanevent(contect,reminderTime,state,reminderMode,classification,userid) values(?,?,?,?,?,?)";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, contect);
			pst.setTimestamp(2,new java.sql.Timestamp(date.getTime()));
			pst.setString(3, state);
			pst.setString(4,reminderMode );
			pst.setString(5, classification);
			pst.setString(6, UserManager.currentLoginUser.getUserid());
			pst.execute();
			pst.close();
		}catch(Exception e){
			e.printStackTrace();
			
		}
	}
	public void deleteEvent(BeanEvent beanevent){
		Connection conn=null;
    	try{
    		conn=DBUtil.getConnection();
			String sql="DELETE FROM beanevent WHERE eventid = ?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, beanevent.getEventId());
			pst.execute();
			pst.close();
			
    	}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	public int getmodifyEventNum(BeanEvent beanevent,String contect,String reminderTime,String state,String reminderMode,String classification )throws Exception{
    	Time t = new Time();
		if(t.timeCompare(t.getCurrentTime(), reminderTime)>=0){
			throw new Exception("ʱ�����ò���������ʱ���ѹ�");
		}
		if(contect.length()>200 ){
			throw new Exception("�������ݳ��Ȳ��ܳ���200����");
		}
		Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(reminderTime);
		Date afterDate = new Date(date .getTime() + 300000);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");  
	    String dateString = formatter.format(afterDate);  
		if(t.timeCompare(t.getCurrentTime(), dateString)>=0){
			throw new Exception("ʱ���С��5����");
		}
		int num=0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select count(*) from beanevent where reminderTime = ? ";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1,reminderTime );
			java.sql.ResultSet rs = pst.executeQuery();
			if(rs.next()){
				num = rs.getInt(1);
			}	
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
		return num;
    }
    public void modifyEvent(BeanEvent beanevent,String contect,String reminderTime,String state,String reminderMode,String classification )throws Exception{
    	
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="update Beanevent set contect=?,reminderTime=?,state=?,reminderMode=?,classification = ? where eventid = ?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, contect);
			pst.setString(2,reminderTime );
			pst.setString(3, state);
			pst.setString(4,reminderMode );
			pst.setString(5, classification);
			pst.setInt(6, beanevent.getEventId());
			pst.execute();
			pst.close();
		}catch(Exception e){
			e.printStackTrace();
			
		}
    }
    public void intoRecycle(BeanEvent beanevent){
    	Connection conn=null;
    	try{
    		conn=DBUtil.getConnection();
			String sql="UPDATE beanevent  SET state = '2' WHERE eventid =?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, beanevent.getEventId());
			pst.execute();
			pst.close();
			
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    public void outRecycle(BeanEvent beanevent){
    	Connection conn=null;
    	try{
    		conn=DBUtil.getConnection();
			String sql="UPDATE beanevent  SET state = '2' WHERE eventid =?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, beanevent.getEventId());
			pst.execute();
			pst.close();
			
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    public List<BeanEvent>  listState(String state,String classification){
		List<BeanEvent> result=new ArrayList<BeanEvent>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql ="select eventId,contect,reminderTime,state,classification,userid from BeanEvent where userId=? and state = ? and classification = ? order by reminderTime ";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, UserManager.currentLoginUser.getUserid());
			pst.setString(2, state);
			pst.setString(3, classification);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanEvent r=new BeanEvent();
				r.setEventId(rs.getInt(1));
				r.setContect(rs.getString(2));
				r.setReminderTime(rs.getString(3));
				r.setState(rs.getString(4));
				r.setClassification(rs.getString(5));

				result.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
    	
    }
    
   /* public List<BeanEvent> listClassification(String classification){
    	List<BeanEvent>  result = new ArrayList<BeanEvent>();
    	Connection conn = null;
    	try{
    		conn = DBUtil.getConnection();
    		String sql= "select eventId,contect,reminderTime,state,classification from BeanEvent where classification=? order by reminderTime desc";
 
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1, classification);
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()){
			BeanEvent r=new BeanEvent();
			r.setEventId(rs.getInt(1));
			r.setContect(rs.getString(2));
			r.setReminderTime(rs.getString(3));
			r.setState(rs.getString(4));
			
			result.add(r);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return result;
    	
    }
    
    public void changeState(String eventid,String state) {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			
			String sql="update BeanEvent set state=? where eventid=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst=conn.prepareStatement(sql);
			pst.setString(1, eventid);
			pst.setString(2, state);
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
	*/
}
